package com.example.sakib.agecalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private TextView ShowAge, EvenOdd, PrimeText , Binary;
    private EditText InputBirthYear;
    private Button Calculate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ShowAge = findViewById(R.id.showageid);
        EvenOdd = findViewById(R.id.EvenOddid);
        PrimeText=findViewById(R.id.PrimeTextid);
        Binary=findViewById(R.id.BinaryGeneratorid);
        InputBirthYear=findViewById(R.id.inputbirthYearid);
        Calculate=findViewById(R.id.calculatebuttonid);

        Calculate();



    }

    public void Calculate(){
        Calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input_age = InputBirthYear.getText().toString();
                int birthdate = Integer.parseInt(input_age);

                Calendar calendar = Calendar.getInstance();

                int currentyear = calendar.get(Calendar.YEAR);
                int age = currentyear-birthdate;

                ShowAge.setText("Your current age is ::: "+age);

                EvenOdd(age);
            }
        });
    }


    public void EvenOdd(int age){
        String text;
        if(age%2==0){
            text=age+" is Even Age ";
            EvenOdd.setText(text);

            Binary.setText("");
            PrimeNumber(age);

        }
        else {
            text=age+" is ODD age ";
            EvenOdd.setText(text);

            PrimeText.setText("");
            DecimalToBinary(age);
        }
    }

    public void PrimeNumber(int age){
        int count=0;
        String primenumbertext;
        for(int i=1;i<=age;i++){
            if(age%i==0){
                count++;
            }
        }
        if(count==2){
            primenumbertext= age+" is a prime number ";
            PrimeText.setText(primenumbertext);

        }

        else if(age==1) {
            primenumbertext=age+" is a  prime number ";
            PrimeText.setText(primenumbertext);
        }

        else {
            primenumbertext=age+" is not a prime number ";
            PrimeText.setText(primenumbertext);
        }
    }

    public void DecimalToBinary(int age){
        int Age = age;
        String binary=" ";
        int binarynumber[] = new int[1000];
        int i =0;
        while (age>0){
            binarynumber[i]=age%2;
            age=age/2;
            i++;
        }
        for(int j=i-1;j>=0;j--){
            binary=binary+binarynumber[j];
        }

        Binary.setText(Age+ " binary is :: "+binary);
    }


}
