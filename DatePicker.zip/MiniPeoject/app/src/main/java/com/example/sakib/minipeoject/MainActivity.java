package com.example.sakib.minipeoject;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button showbutton;
    DatePicker datePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        showbutton=findViewById(R.id.showbutton);
        datePicker=findViewById(R.id.datepicker);
        showbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                View popupview = getLayoutInflater().inflate(R.layout.activity_popupactivity,null);
                TextView date = popupview.findViewById(R.id.popdate);
                TextView month = popupview.findViewById(R.id.popmonth);
                TextView year = popupview.findViewById(R.id.popleapyear);
                ImageButton imageButton = popupview.findViewById(R.id.exit);
                date.setText(showdate());
                month.setText(monthEvenOdd());
                year.setText(leapyear());


                builder.setView(popupview);
                final AlertDialog dialog = builder.create();
                dialog.show();

                imageButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.cancel();
                    }
                });
            }
        });

    }


    public String showdate(){
        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append(datePicker.getDayOfMonth()+"/");
        stringBuilder.append(datePicker.getMonth()+1+"/");
        stringBuilder.append(datePicker.getYear());

        return stringBuilder.toString();
    }

    public String monthEvenOdd(){
        int numberofMonth = datePicker.getMonth()+1;
        String text;
        if(numberofMonth%2==0){
            text = "This is " + numberofMonth+"th Month which is EVEN" ;
        }
        else{
            text = "This is "+numberofMonth+"th month which is ODD";
        }
        return text;
    }

    public String leapyear(){
        int year = datePicker.getYear();
        String yeartext;

        if((year % 400)==0){
            yeartext =(year+" is a leap year \n ");
        }
        else if((year % 100)==0){
            yeartext =(year+" is a leap not year \n ");
        }
        else if((year % 4)==0){
            yeartext =(year+" is a leap year \n ");
        }
        else {
            yeartext =(year+" is not a leap year \n ");
        }
        return yeartext;
    }

}
